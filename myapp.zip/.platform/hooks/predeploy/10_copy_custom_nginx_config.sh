#!/bin/bash
echo 'Post deploy executing'
cp /var/app/current/.platform/nginx/01_custom_nginx_config.conf /etc/nginx/conf.d
echo 'Post deploy executing'